import React, { Component } from 'react'
import { StyleSheet,Text,View} from 'react-native';

export default class InfoScreen extends Component {
  render() {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Text>Info Screen</Text>
      </View>
    )
  }
}